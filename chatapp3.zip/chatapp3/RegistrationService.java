/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp3;
import javax.swing.JOptionPane;
/**
 *
 * @author vunwe
 */
public class RegistrationService {

    public User registerAndLogin() {
        String username = JOptionPane.showInputDialog("Enter a username (_ and max 5 chars):");
        while (!User.isValidUsername(username)) {
            username = JOptionPane.showInputDialog("Invalid! Username must contain _ and be ≤ 5 chars:");
        }

        String password = JOptionPane.showInputDialog("Enter a strong password (8+ chars, upper, lower, digit, special):");
        while (!User.isValidPassword(password)) {
            password = JOptionPane.showInputDialog("Invalid! Try again:");
        }

        User user = new User(username, password);

        String loginUser = JOptionPane.showInputDialog("Login - Enter username:");
        String loginPass = JOptionPane.showInputDialog("Login - Enter password:");

        if (loginUser.equals(user.getUsername()) && loginPass.equals(user.getPassword())) {
            return user;
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Username or password incorrect.");
            return null;
        }
    }
}

   