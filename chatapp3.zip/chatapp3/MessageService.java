/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp3;
import javax.swing.*;
/**
 *
 * @author vunwe
 */
public class MessageService {
    private Message[] messages = new Message[100];
    private int count = 0;

    public void sendMessage(String sender, String recipient, String content) {
        messages[count++] = new Message(sender, recipient, content);
        JOptionPane.showMessageDialog(null, "Message sent successfully!");
    }

    public String getMessagesReport() {
        StringBuilder report = new StringBuilder();
        for (int i = 0; i < count; i++) {
            report.append(messages[i].toString()).append("\n----------------\n");
        }
        return report.toString();
    }

    public String getLongestMessage() {
        int maxLen = -1;
        Message longest = null;
        for (int i = 0; i < count; i++) {
            if (messages[i] != null && messages[i].getLength() > maxLen) {
                maxLen = messages[i].getLength();
                longest = messages[i];
            }
        }
        return (longest != null) ? longest.toString() : "No messages found.";
    }

    public String searchByRecipient(String recipient) {
        StringBuilder found = new StringBuilder();
        for (int i = 0; i < count; i++) {
            if (messages[i] != null && messages[i].getRecipient().equalsIgnoreCase(recipient)) {
                found.append(messages[i].toString()).append("\n\n");
            }
        }
        return found.length() > 0 ? found.toString() : "No messages to " + recipient + ".";
    }

    public boolean deleteMessageByHash(String hash) {
        for (int i = 0; i < count; i++) {
            if (messages[i] != null && messages[i].getHash().equals(hash)) {
                for (int j = i; j < count - 1; j++) {
                    messages[j] = messages[j + 1];
                }
                messages[--count] = null;
                return true;
            }
        }
        return false;
    }
}
