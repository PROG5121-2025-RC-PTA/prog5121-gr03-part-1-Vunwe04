/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp3;
import javax.swing.JOptionPane;
/**
 *
 * @author vunwe
 */
public class ChatApp3 {
 public static void main(String[] args) {
        RegistrationService registration = new RegistrationService();
        User user = registration.registerAndLogin();  // Registration + login

        if (user == null) {
            JOptionPane.showMessageDialog(null, "Exiting. Registration/Login failed.");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat, " + user.getUsername());
        MessageService service = new MessageService();

        while (true) {
            String option = JOptionPane.showInputDialog(
                "1: Send Message\n2: View Messages Report\n3: Search by Recipient\n4: Longest Message\n5: Delete Message by Hash\n6: Exit");

            switch (option) {
                case "1":
                    String to = JOptionPane.showInputDialog("Enter recipient:");
                    String msg = JOptionPane.showInputDialog("Enter your message:");
                    service.sendMessage(user.getUsername(), to, msg);
                    break;
                case "2":
                    JOptionPane.showMessageDialog(null, service.getMessagesReport());
                    break;
                case "3":
                    String searchTo = JOptionPane.showInputDialog("Enter recipient to search:");
                    JOptionPane.showMessageDialog(null, service.searchByRecipient(searchTo));
                    break;
                case "4":
                    JOptionPane.showMessageDialog(null, service.getLongestMessage());
                    break;
                case "5":
                    String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
                    boolean deleted = service.deleteMessageByHash(hash);
                    String delMsg = deleted ? "Message deleted successfully." : "Message not found.";
                    JOptionPane.showMessageDialog(null, delMsg);
                    break;
                case "6":
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Try again.");
            }
        }
    }
}