/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp3;
/**
 *
 * @author vunwe
 */
public class Message {
    private String sender;
    private String recipient;
    private String content;
    private String hash;

    public Message(String sender, String recipient, String content) {
        this.sender = sender;
        this.recipient = recipient;
        this.content = content;
        this.hash = Integer.toHexString((sender + recipient + content).hashCode());
    }

    public String getRecipient() {
        return recipient;
    }

    public String getHash() {
        return hash;
    }

    public int getLength() {
        return content.length();
    }

    public String toString() {
        return "From: " + sender + "\nTo: " + recipient + "\nMessage: " + content + "\nHash: " + hash;
    }
}
