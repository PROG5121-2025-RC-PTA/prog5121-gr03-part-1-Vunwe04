/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp2;
import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author vunwe
 */
public class MessageSender{
    public static boolean sendMessage(int messageNumber) {
        String recipient = JOptionPane.showInputDialog("Enter recipient number (must start with +):");
        String text = JOptionPane.showInputDialog("Enter your message (max 250 characters):");

        Message msg = new Message(recipient, text, messageNumber);

        if (!msg.checkRecipientCell()) {
            JOptionPane.showMessageDialog(null, "Invalid recipient number.");
            return false;
        }

        if (!msg.checkMessageLength()) {
            JOptionPane.showMessageDialog(null, "Please enter a message of less than 250 characters.");
            return false;
        }

        String option = JOptionPane.showInputDialog("Choose:\n1) Send Message\n2) Disregard Message\n3) Store Message");

        switch (option) {
            case "1":
                JOptionPane.showMessageDialog(null,
                        "Message Sent\n" +
                        "Message ID: " + msg.messageID + "\n" +
                        "Message Hash: " + msg.createMessageHash() + "\n" +
                        "Recipient: " + msg.recipient + "\n" +
                        "Message: " + msg.text);
                return true;

            case "2":
                JOptionPane.showMessageDialog(null, "Message disregarded.");
                return false;

            case "3":
                saveMessageToFile(msg);
                JOptionPane.showMessageDialog(null, "Message stored for later.");
                return false;

            default:
                JOptionPane.showMessageDialog(null, "Invalid option.");
                return false;
        }
    }

    private static void saveMessageToFile(Message msg) {
        String json = String.format("{\"MessageID\":\"%s\",\"MessageHash\":\"%s\",\"Recipient\":\"%s\",\"Message\":\"%s\"}",
                msg.messageID,
                msg.createMessageHash(),
                msg.recipient,
                msg.text.replace("\"", "\\\""));

        try (FileWriter writer = new FileWriter("messages.json", true)) {
            writer.write(json + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Failed to store message.");
        }
    }
}
