/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.chatapp2;
import javax.swing.*;
/**
 *
 * @author vunwe
 */
public class ChatApp2 {
    public static void main(String[] args) {
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");

        if (!username.equals("vunwe") || !password.equals("1234")) {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting...");
            return;
        }

        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
        int maxMessages = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to send?"));
        int sentCount = 0;

        while (true) {
            String option = JOptionPane.showInputDialog("Choose:\n1) Send Message\n2) Show Recently Sent Messages\n3) Quit");

            switch (option) {
                case "1":
                    if (sentCount < maxMessages) {
                        boolean sent = MessageSender.sendMessage(sentCount);
                        if (sent) sentCount++;
                    } else {
                        JOptionPane.showMessageDialog(null, "You have reached the message limit.");
                    }
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;

                case "3":
                    JOptionPane.showMessageDialog(null, "Total messages sent: " + sentCount);
                    return;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }
}

