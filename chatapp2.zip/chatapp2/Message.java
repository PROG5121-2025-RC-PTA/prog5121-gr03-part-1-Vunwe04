/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp2;
import java.util.Random;
/**
 *
 * @author vunwe
 */
public class Message {
    public String messageID;
    public int messageNumber;
    public String recipient;
    public String text;

    public Message(String recipient, String text, int messageNumber) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.text = text;
        this.messageNumber = messageNumber;
    }

    private String generateMessageID() {
        Random rand = new Random();
        long num = Math.abs(rand.nextLong()) % 1_000_000_0000L;
        return String.format("%010d", num);
    }

    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    public boolean checkRecipientCell() {
        return recipient.startsWith("+27") && recipient.length() <= 12;
    }

    public boolean checkMessageLength() {
        return text.length() <= 250;
    }

    public String createMessageHash() {
        String[] words = text.trim().split("\\s+");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return messageID.substring(0, 2) + ":" + messageNumber + ":" +
                first.toUpperCase() + last.toUpperCase();
    }
}
