/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author vunwe
 */
public class LoginTest {  
    private final LoginService loginService = new LoginService();

    @Test
    public void testUsernameValidFormat() {
        // Correct format: contains underscore, max 5 chars
        assertTrue(loginService.isUsernameValid("vu_mw"));
    }

    @Test
    public void testUsernameTooLong() {
        // Too long: more than 5 characters
        assertFalse(loginService.isUsernameValid("vunwe_mthombeni"));
    }

    @Test
    public void testUsernameMissingUnderscore() {
        // Missing underscore
        assertFalse(loginService.isUsernameValid("vuwe"));
    }

    @Test
    public void testPasswordComplexityValid() {
        // Complex: contains special character, number, uppercase, etc.
        assertTrue(loginService.isPasswordComplex("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordMissingSpecialChar() {
        assertFalse(loginService.isPasswordComplex("Cheesecake99"));
    }

    @Test
    public void testPasswordMissingNumbers() {
        assertFalse(loginService.isPasswordComplex("Ch@rmStr!ng"));
    }

    @Test
    public void testPasswordTooShort() {
        assertFalse(loginService.isPasswordComplex("Ch@1!"));
    }
}