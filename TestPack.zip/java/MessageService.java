/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vunwe
 */
public class MessageService {
    private Message[] messages;
    private int messageCount;

    public MessageService() {
        messages = new Message[100]; 
        messageCount = 0;
    }

    public boolean sendMessage(String recipient, String content) {
        if (messageCount >= messages.length) {
            return false; 
        }
        Message msg = new Message(recipient, content);
        messages[messageCount] = msg;
        messageCount++;
        return true;
    }

    public boolean deleteMessageByHash(String hash) {
        for (int i = 0; i < messageCount; i++) {
            if (messages[i].getHash().equals(hash)) {
                
                for (int j = i; j < messageCount - 1; j++) {
                    messages[j] = messages[j + 1];
                }
                messages[messageCount - 1] = null;
                messageCount--;
                return true;
            }
        }
        return false;
    }

    public String getLongestMessage() {
        if (messageCount == 0) return "No messages sent.";

        Message longest = messages[0];
        for (int i = 1; i < messageCount; i++) {
            if (messages[i].getContent().length() > longest.getContent().length()) {
                longest = messages[i];
            }
        }
        return "Longest Message:\nTo: " + longest.getRecipient() +
               "\nMessage: " + longest.getContent() +
               "\nHash: " + longest.getHash();
    }
    
    public String searchByRecipient(String recipient) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < messageCount; i++) {
            if (messages[i].getRecipient().equalsIgnoreCase(recipient)) {
                result.append("To: ").append(messages[i].getRecipient())
                      .append(" | Message: ").append(messages[i].getContent())
                      .append(" | Hash: ").append(messages[i].getHash())
                      .append("\n");
            }
        }
        return result.length() == 0 ? "No messages found for " + recipient : result.toString();
    }

    public String getMessagesReport() {
        if (messageCount == 0) return "No messages to show.";
        StringBuilder report = new StringBuilder("All Sent Messages:\n");
        for (int i = 0; i < messageCount; i++) {
            report.append("To: ").append(messages[i].getRecipient())
                  .append(" | Message: ").append(messages[i].getContent())
                  .append(" | Hash: ").append(messages[i].getHash())
                  .append("\n");
        }
        return report.toString();
    }

    
    public Message[] getMessages() {
        return messages;
    }

    public int getMessageCount() {
        return messageCount;
    }
}