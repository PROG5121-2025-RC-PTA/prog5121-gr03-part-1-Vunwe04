/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.UUID;
/**
 *
 * @author vunwe
 */
class Message {
    private String recipient;
    private String content;
    private String hash;

    public Message(String recipient, String content) {
        this.recipient = recipient;
        this.content = content;
        this.hash = generateHash();  // Generate a unique hash
    }

    private String generateHash() {
        return UUID.randomUUID().toString().substring(0, 8);
    }

    public String getRecipient() {
        return recipient;
    }

    public String getContent() {
        return content;
    }

    public String getHash() {
        return hash;
    }

    @Override
    public String toString() {
        return "To: " + recipient + " | Message: " + content + " | Hash: " + hash;
    }
}
