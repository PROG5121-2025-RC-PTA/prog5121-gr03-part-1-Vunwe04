/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/**
 *
 * @author vunwe
 */
public class MessageServiceTest {

    private MessageService messageService;

    @BeforeEach
    public void setUp() {
        messageService = new MessageService();
    }

    @Test
    public void testSendMessageAddsMessageToArray() {
        boolean success = messageService.sendMessage("John", "Hi John!");
        assertTrue(success);
        assertEquals(1, messageService.getMessageCount());
    }

    @Test
    public void testDeleteMessageByHashRemovesMessage() {
        messageService.sendMessage("Anna", "Hello Anna");
        String hash = messageService.getMessages()[0].getHash();
        boolean deleted = messageService.deleteMessageByHash(hash);
        assertTrue(deleted);
        assertEquals(0, messageService.getMessageCount());
    }

    @Test
    public void testGetLongestMessage() {
        messageService.sendMessage("User1", "Short msg");
        messageService.sendMessage("User2", "This is the longest message so far.");
        String longest = messageService.getLongestMessage();
        assertTrue(longest.contains("User2"));
        assertTrue(longest.contains("longest message"));
    }

    @Test
    public void testSearchByRecipientReturnsCorrectMessage() {
        messageService.sendMessage("Mike", "Hey Mike");
        messageService.sendMessage("Mike", "Second message");
        messageService.sendMessage("Sara", "Different recipient");

        String result = messageService.searchByRecipient("Mike");
        assertTrue(result.contains("Hey Mike"));
        assertTrue(result.contains("Second message"));
        assertFalse(result.contains("Sara"));
    }
}